<?php

return [
  'income' => 'উপার্জন',
  'expense' => 'খরচ',
];
