<?php

return [
  'income' => 'Income',
  'expense' => 'Expense',
];
