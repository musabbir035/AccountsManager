<template>
  <div>
    <b-form> lalala </b-form>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>