<template>
  <div>
    <h1>This is Home</h1>
  </div>
</template>

<script>
export default {};
</script>
